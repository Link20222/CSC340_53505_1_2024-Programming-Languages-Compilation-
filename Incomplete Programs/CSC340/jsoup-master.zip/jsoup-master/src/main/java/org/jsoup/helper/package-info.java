/**
 Package containing classes supporting the core jsoup code.
 */
@NullMarked
package org.jsoup.helper;

import org.jspecify.annotations.NullMarked;
