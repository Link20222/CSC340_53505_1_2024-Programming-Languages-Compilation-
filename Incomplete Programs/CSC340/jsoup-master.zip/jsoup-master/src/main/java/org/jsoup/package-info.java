/**
 Contains the main {@link org.jsoup.Jsoup} class, which provides convenient static access to the jsoup functionality.
 */
@NullMarked
package org.jsoup;

import org.jspecify.annotations.NullMarked;
