/**
 Contains the HTML parser, tag specifications, and HTML tokeniser.
 */
@NullMarked
package org.jsoup.parser;

import org.jspecify.annotations.NullMarked;
