/**
 Contains the jsoup HTML cleaner, and safelist definitions.
 */
@NullMarked
package org.jsoup.safety;

import org.jspecify.annotations.NullMarked;