/**
 Packages to support the CSS-style element selector.
 {@link org.jsoup.select.Selector Selector defines the query syntax.}
 */
@NullMarked
package org.jsoup.select;

import org.jspecify.annotations.NullMarked;
