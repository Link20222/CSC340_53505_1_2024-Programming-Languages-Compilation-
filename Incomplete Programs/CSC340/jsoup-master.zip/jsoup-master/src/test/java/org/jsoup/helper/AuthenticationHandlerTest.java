package org.jsoup.helper;

public class AuthenticationHandlerTest {
    public static final int MaxAttempts = AuthenticationHandler.MaxAttempts;

    // tests are in ConnectionTest, ProxyTest. This class just makes the MaxAttempts visible for test.
}
